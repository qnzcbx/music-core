# 字间琴音 · voice-between

由 v2.4 原型拆分的 pnpm + Vite + TypeScript 工程。提供框架无关 Core、Input、Visual、原生 Demo 和 Vue 3 组件。

## 安装到 Vue 3 应用

包入口 `VoiceBetween` 是琴体嵌入版，只渲染乐器、状态读数及必要控制。

```bash
pnpm add ./voice-between-0.2.1.tgz
```

宿主需要 Vue 3.5+。Vue 是 peer dependency，包内不再打包一份 Vue；JS、类型声明、Shadow DOM 样式和 SVG 琴体均包含在安装包内，无需额外导入 CSS 或复制资源目录。当前提供 ESM 格式。

```vue
<script setup lang="ts">
import { onBeforeUnmount, ref, watch } from 'vue';
import { VoiceBetween, type VoiceBetweenHandle } from 'voice-between';
const piano = ref<VoiceBetweenHandle>();
const input = ref<HTMLInputElement>();
let unbind: (() => void) | undefined;
watch([piano, input], ([instrument, element]) => {
  unbind?.();
  unbind = instrument && element ? instrument.bindInputElement(element) : undefined;
}, { flush: 'post' });
onBeforeUnmount(() => unbind?.());
</script>
<template>
  <input ref="input" type="search" aria-label="搜索" />
  <VoiceBetween ref="piano" />
</template>
```

推荐使用 `bindInputElement`：组件只监听显式传入的元素，不读写搜索值，不查找宿主 DOM。每个实例只绑定一个元素，换绑先释放旧绑定；返回的清理函数可重复调用，旧清理不会误解绑新元素。物理键优先，拼音预编辑比较增量并按单次编辑去重，确实插入文字且本轮未响时才上屏兜底。粘贴、删除、空白、程序回填及取消组合静默。缺少物理按键且不暴露拼音预编辑的输入法，只能在最终上屏时补响；非拼音候选替换也不模拟逐键发声。

绑定与手动转发二选一，同一输入框不要再同时调用 `feedKeyDown` / `feedKeyUp` / `feedInput`。下面保留旧手动 API 的契约。

`feedInput` 接受结构化的 `HostInput`：`{ data: string | null, inputType?: string, isComposing?: boolean }`，可以直接传 `InputEvent`。只处理已提交的插入事件；组合中间态、删除、空数据和纯空白不演奏。每次事件使用首个非空白 Unicode 字符：字母和数字复用物理键位映射，其余字符复用软键盘回退音阶；一次粘贴多个字符只演奏一次。简单接入只转交 `input`；若同时使用物理键位接口，按下文示例职责去重，不要在 `compositionend` 再重复提交。无效、已卸载或静音时返回 `false`，成功转交返回 `true`。

自由键盘演奏仅在琴体演奏区聚焦时启用，可 Tab 进入演奏区或直接点击/触屏演奏。组件不在 document/window 安装键盘监听，不拦截宿主搜索框或表单；未转交的外部输入不发声。Tab / Shift+Tab 保留原生导航。

| 属性 / 事件 | 行为 |
| --- | --- |
| `theme` | `'light'`（默认）或 `'dark'`；嵌入版只由宿主传入，无独立主题开关 |
| `showControls` | 默认 `true`；设为 `false` 时隐藏琴体外的顶部控制条与乐器/状态行，保留钢琴面板按钮、指示灯、琴键及琴体装饰 |
| `transparent` | 默认 `false`；设为 `true` 时外层与舞台使用透明背景，琴体材质保留 |
| `muted` | 默认 `false`；变化时同步组件静音状态，阻止新声音及嵌入版新音符事件，已存在尾音自然结束 |
| `keyboardEnabled` | 默认 `true`；控制琴区、绑定输入及手动 `feedKeyDown` / `feedInput`；keyup、释放和指针演奏仍可用 |
| `showControls` | 默认 `true`，可隐藏乐器控制与状态栏 |
| `transparent` | 默认 `false`，可透明嵌入宿主背景 |
| `note-on` | `{ midi, velocity, source }`，MIDI 为乐器实际演奏音高 |

`VoiceBetweenHandle` 提供 `bindInputElement`、`feedKeyDown`、`feedKeyUp`、`releaseHostKeys`、`feedInput`、`setMuted`、`setSustain`、`setInstrument('auto' | 'piano' | 'guqin' | 'lyre')`、`getState` 和异步 `dispose`。Vue 卸载自动清理；需要提前停止时可 `await piano.value?.dispose()`，之后旧引用不再响应输入。初次挂载前与卸载后 `getState()` 返回 `undefined`。琴体按钮也可设置静音/延音，当前值可通过 `getState()` 读取；宿主 prop 在值发生变化时同步。

嵌入版默认按容器宽度切换：`>960` 钢琴、`561–960` 古琴、`≤560` 莱雅琴，支持手动选择及返回自动。三种乐器均默认常驻延音，仍可手动关闭。`createPianoCore` 等框架无关能力也可从 `voice-between/core` 导入。

## 构建与本地打包

```bash
pnpm install --frozen-lockfile
pnpm typecheck
pnpm build                         # dist/：ESM 库和声明
pnpm build:demo                    # demo-dist/：独立与 Vue Demo
pnpm pack --pack-destination artifacts
pnpm verify:package                # 新临时目录安装 tgz、类型检查、生产构建并用 preview 验证
```

`prepack` 会重新构建库；`pnpm pack` 仅包含 `dist/`、README 和包元数据，不包含源码、开发任务、验收截图或测试 Fixture。不发布 npm。`verify:package` 会保留独立消费端临时目录，默认将包和验证结果放在 `test-results/package/`；可用 `VOICE_BETWEEN_PACKAGE_EVIDENCE` 与 `TYPING_PIANO_TEST_REPORT` 指定新的证据位置。消费端 Fixture 位于 `tests/fixtures/vue-consumer/`，复制后只依赖本地 tgz 和普通 npm 依赖，没有源仓库别名或相对源码引用。

以下运行、演进记录及本地验收链接用于源码开发，不属于安装包中的独立资源。

## 运行（Git Bash）

需要 Node.js 22.12+、pnpm 11.1.2。

```bash
pnpm install --frozen-lockfile
pnpm dev
```

打开 http://127.0.0.1:5176/examples/vanilla/ 。浏览器首次发声需要用户交互。保留的原版对照页面是 `/tasks/assets/typing_piano_v2_4.html`。

```bash
pnpm typecheck
pnpm build
pnpm exec playwright install chromium
pnpm test
```

测试使用独立 Vite 进程；5176 应为空闲。测试结束后自动关闭服务。pnpm-workspace.yaml 只允许 esbuild 必需的安装构建脚本。

## 结构与边界

- `src/core/state.ts`：纯状态模型，返回状态副本。
- `src/core/audio.ts`：Web Audio 节点、原音色参数合成及声音资源释放。
- `src/core/index.ts`：协调状态和音频，提供框架无关 API。
- `src/input/`：键盘、快捷键、IME 和 Pointer；通过回调调用宿主，提供 dispose。
- `src/visual/`：共享 Canvas 粒子、琴壳共鸣线及弦振帧调度；从 Core 获取波形快照。
- `src/piano/`：共享页面模板、样式、弦乐命中映射与装配入口。
- `examples/vanilla/`、`examples/vue/`：原生演示和 Vue 宿主演示。
- `tests/`：直接运行原版与工程版的 Playwright 回归和截图对照。
- `notes/`：结构审计、验收报告、JSON 测试结果及截图证据。
- `tasks/assets/typing_piano_v2_4.html`：只读基线。

## Core API

```ts
import { createPianoCore } from './src';

const piano = createPianoCore();
piano.noteOn(60, 'physical', 0.9);
piano.noteOff(60);
piano.setTimbre(1); // 0 三角钢琴、1 柔音毛毡、2 清澈八音盒
piano.setSustain(true);
piano.setMuted(false);
const state = piano.getState();
await piano.dispose();
```

`noteOn` 返回实际力度，无效音符或已销毁实例返回 null。`noteOff` 在延音踏板开启时保留尾音。`setMuted` 延续基线语义：阻止后续声音触发，已经响起的声音按原包络自然结束。`readWaveform` 供 Visual 读取瞬时波形。`dispose` 清理声音定时器、断开节点并关闭 AudioContext，可重复调用；销毁后不再接受演奏和状态修改。

可注入 `createAudioContext` 工厂；`isHeld(midi)` 由宿主输入层提供，帮助松开延音时保留仍被按住的声音。Core 不操作 DOM，不导入 Vue。

`mountTypingPiano(root)` 是 Demo 装配入口，返回原演示 API 和异步 dispose。重新挂载前先 `await instance.dispose()`。为保持原版全局快捷键，Input 监听 document；原生 Demo 一个页面应只激活一个输入实例，主题沿用页面级设置；Vue 包装通过作用域、Shadow DOM 和相同生命周期约定隔离宿主。

36 键、Shift 低音黑键、Space、Alt 快捷键、中文组合输入回退、触屏滑奏、回放和暗黑主题均保留。自动化 IME/触屏事件不代表实际操作系统候选窗和物理触屏已验收，详见 [验收报告](notes/01/01-Stage-A验收.md)。


## Vue 接入演示

打开 `http://127.0.0.1:5176/examples/vue/`。标题、打字框、回放和主题选择均属于宿主页；`VoiceBetween` 只负责琴体。页面展示物理键位转交、文本输入去重、失焦释放、静音、主题、透明背景及控制显隐。未向组件转交的其他表单输入不会演奏。

推荐使用本页开头的元素绑定示例。仅在自行管理输入事件时才使用手动接口。需要完整物理键位时，在选定输入框转交 `feedKeyDown(event)` 和 `feedKeyUp(event)`，失焦调用 `releaseHostKeys()`；若 keydown 返回 true，跳过紧随其后的同一次文本 input。组合中间态忽略，缺少物理键位的软键盘提交继续使用 `feedInput`。这些宿主监听不调用 preventDefault，不接管搜索快捷键或 Tab 导航。

完整可运行写法见 [Vue 演示页](examples/vue/App.vue)；包安装与生产构建验证见 [独立消费端](tests/fixtures/vue-consumer/src/App.vue)。两个示例均直接使用当前正式接口，没有旧组件测试宿主。

0.2.0 移除了 `TypingPiano` 导出。原先使用它的 Vue 页面应改为 `VoiceBetween`，将标题和输入控件放到宿主；不能只改组件名后继续查询组件内部的输入框。原生独立 Demo 保留输入框和演奏功能；0.2.1 取消 Tab 切音色。

## Stage C2 乐器与回归

默认按组件实际可用宽度自动选琴：大于 960 px 为 C1 舞台钢琴，561–960 px 为七弦十三徽古琴，560 px 及以下为 C4–C6 的 15 弦新月莱雅琴。宽窗口中的窄 Vue 栏也按栏宽切换。琴体上方的选择框可手动选琴或返回自动；手动模式不会被 resize 覆盖，窄屏手动钢琴保留横向滚动。

三种乐器共用输入调度、AudioContext 和 Canvas 循环。自动换琴不试听；每次换琴清除持有的键与指针、临时和锁定延音、旧余音、粒子及待执行回放。新挂载和切换后的三种乐器均默认开启常驻延音，可通过延音按钮手动关闭；松开 Space 不会关闭常驻延音。当前文字、静音与钢琴音色选择保留。古琴按触点横坐标选音位，支持跨弦滑奏；莱雅琴半音取最近自然音，等距取低音，超出 C4–C6 的输入夹到端弦。发声、读数、弦振及 `note-on` 使用同一解析结果。

共享挂载实例增加 `setInstrument('auto' | 'piano' | 'guqin' | 'lyre')`，`getState()` 包含 `instrument` 与 `instrumentMode`。Vue 的 `keyboardEnabled`、`theme`、`note-on` 契约保持原状。

```bash
# 日常 C1 / C2、Vue 和输入作用域回归；截图默认进入 test-results，避免改写历史证据
PLAYWRIGHT_PORT=5178 pnpm exec playwright test tests/stage-c1.spec.mjs tests/stage-c2.spec.mjs tests/vue.spec.mjs tests/input-scope.spec.mjs
# 独立历史 v2.4 对照：视觉差异保持原阈值，预期报告五项失败
PLAYWRIGHT_PORT=5178 pnpm exec playwright test tests/regression.spec.mjs
```

C2 自动窄屏换琴是有意的视觉变化，C1 中四项 Stage B 整页窄屏像素断言已标为不适用，不覆盖或回填旧基线；桌面琴体及演奏行为继续回归。需要留存验收证据时，为每次运行指定新的 `TYPING_PIANO_C1_EVIDENCE_DIR`、`TYPING_PIANO_C2_EVIDENCE_DIR`、`TYPING_PIANO_VUE_EVIDENCE_DIR`、`TYPING_PIANO_EVIDENCE_DIR` 和 `TYPING_PIANO_TEST_REPORT` 路径。

详见 [Stage C1 记录](notes/03/03-Stage-C1验收.md) 和 [Stage C2 验收记录](notes/04/04-Stage-C2验收.md)。真实 Windows 拼音候选窗、真机软键盘、多指实体触屏、跨浏览器与耳听音色仍待人工确认；非静音波形仅证明有音频输出。


宿主页只需要琴体时，可使用 `<VoiceBetween :show-controls="false" transparent :theme="theme" />`，无需跨 Shadow DOM 改样式。

钢琴面板电源键旁的音量胶囊与三颗电平灯，按 0.38 / 0.64 / 0.88 三档调整乐器自己的输出增益；不控制宿主音乐播放器。`createPianoCore().setVolume(0..1)` 不提前创建 AudioContext。

透明嵌入：移除琴体周围的宽幅环境光晕，改用轻接触影；放开外层裁切以免阴影形成矩形断边。古琴收紧 SVG 留白并提高最大展示宽度，保留琴身、十三徽及流苏。


## 0.2.1 输入绑定与快捷键

Tab / Shift+Tab 只做原生焦点导航，不切音色。在绑定输入框或聚焦琴区使用 Alt+1 / Alt+2 / Alt+3 选择三种钢琴音色，Alt+K 切换键位提示。嵌入快捷键不阻止默认编辑行为，组合候选阶段不触发快捷键；其他输入框不接管。关闭 keyboardEnabled、失焦、窗口失焦、解绑和卸载会释放接管的按键并清理待配对状态。
