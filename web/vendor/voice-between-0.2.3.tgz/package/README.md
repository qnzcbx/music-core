# 弦外之音 · Voice Between

一个可以嵌进 Vue 应用的键盘乐器。你可以直接弹琴，也可以让指定的输入框随打字发声。点钢琴面板上的 ▶，还能把输入框里的文字编成一段旋律。

## 安装

从项目获取 `voice-between-0.2.3.tgz`，在 Vue 应用根目录安装：

```bash
pnpm add ./voice-between-0.2.3.tgz
```

宿主需要 Vue 3.5+。安装包提供 ESM、类型声明、Shadow DOM 样式和琴体资源，无需额外导入 CSS。

## 接入 Vue

用 `bindInputElement()` 把输入框交给组件。下面的示例只展示琴体，并开启钢琴面板上的 ▶。

```vue
<script setup lang="ts">
import { ref, watch } from 'vue';
import { VoiceBetween, type VoiceBetweenHandle } from 'voice-between';

const piano = ref<VoiceBetweenHandle | null>(null);
const input = ref<HTMLInputElement | null>(null);

watch(
  [piano, input],
  ([instrument, element], _, onCleanup) => {
    if (instrument && element) {
      onCleanup(instrument.bindInputElement(element));
    }
  },
  { flush: 'post' },
);
</script>

<template>
  <input ref="input" type="search" aria-label="搜索" />
  <VoiceBetween ref="piano" text-melody-enabled />
</template>
```

组件默认只渲染乐器，Demo 的切琴下拉框和读数不进入嵌入 DOM。宿主如需控制，可通过实例 API 提供自己的控件。组件只接管绑定的输入框和琴体演奏区，不改写输入内容，不提交表单。同一输入框使用元素绑定后，不要再转发 `feedKeyDown`、`feedKeyUp` 或 `feedInput`，以免重复发声。

### 演奏与文字旋律

- **直接弹奏**：点击或触摸琴体，也可以按 Tab 聚焦演奏区后用键盘弹奏。
- **边打边响**：在绑定的输入框里打字。中文输入法若不向浏览器暴露拼音预编辑，只能在文字上屏时发声。
- **点 ▶ 播放文字旋律**：点击时读取已绑定输入框的当前值。有字就按文字生成旋律，空白就弹七音琶音。它不是演奏录音。播放中再次点击 ■ 可停止，不会改写输入或主动把焦点移回输入框。
- **快捷键**：在绑定的输入框或琴体演奏区，`Alt+1` / `Alt+2` / `Alt+3` 切换钢琴音色，`Alt+K` 切换键位提示。`Tab` / `Shift+Tab` 保留原生焦点导航。

组件按自身宽度选琴：超过 960 px 是钢琴，超过 560 px 至 960 px 是古琴，560 px 及以下是莱雅琴。通过组件实例的 `setInstrument('piano' | 'guqin' | 'lyre' | 'auto')` 指定或返回自动。

### 常用属性

| 属性 | 默认值 | 用途 |
| --- | --- | --- |
| `theme` | `'light'` | 设为 `'dark'` 使用暗色主题。 |
| `transparent` | `false` | 使外层和舞台背景透明，保留琴体材质。 |
| `muted` | `false` | 停止文字旋律的后续调度并阻止新声音，已有尾音自然结束。 |
| `keyboardEnabled` | `true` | 关闭后暂停键盘和绑定输入的演奏，仍可点击或触摸琴体。 |
| `textMelodyEnabled` | `false` | 挂载时读取。启用后在钢琴面板的 K 右侧显示 ▶，不依赖外部控制条。 |

`note-on` 事件返回 `{ midi, velocity, source }`。框架无关的音频核心可从 `voice-between/core` 导入。

## 本地开发

使用 Node.js 22.x（22.12 或更新）和 pnpm。安装依赖并启动 Demo：

```bash
pnpm install --frozen-lockfile
pnpm dev
```

打开 [原生 Demo](http://127.0.0.1:5176/examples/vanilla/) 或 [Vue Demo](http://127.0.0.1:5176/examples/vue/)。浏览器需要用户交互才能首次发声。

构建和打包：

```bash
pnpm typecheck
pnpm build
mkdir -p artifacts
pnpm pack --pack-destination artifacts
```

`pnpm verify:package` 会在独立的 Vue 应用中安装生成的本地包，验证类型和生产构建。项目通过 `.tgz` 分发，不需要发布到 npm。
